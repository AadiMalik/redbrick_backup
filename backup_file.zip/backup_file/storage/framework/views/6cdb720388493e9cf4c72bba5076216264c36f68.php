
<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="page-breadcrumb">
            <div class="row">
                <div class="col-12 d-flex no-block align-items-center">
                    <h4 class="page-title">Dashboard</h4>
                    <div class="ms-auto text-end">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="#">Backups</a></li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    Backup
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">My Backups</h5>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <?php if(session()->has('alert-success')): ?>
                                    <div class="alert alert-success" style="margin-bottom:0;">
                                        <?php echo e(session()->get('alert-success')); ?>

                                    </div>
                                <?php endif; ?>
                                <table class="table table-responsive-lg table-bordered" style="width:100%;">
                                    <thead>
                                        <tr>
                                            <th scope="col">Sr. No</th>
                                            <th scope="col">File</th>
                                            <th scope="col">Size</th>
                                            <th scope="col">Created At</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $backup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr style=" font-weight:bold;">
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($item->name); ?></td>
                                                <td><?php echo e(number_format((float) $item->size / 1024, 2, '.', '')); ?> kb</td>
                                                <td><?php echo e($item->created_at); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('after-script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\backup_file\resources\views/user/backup.blade.php ENDPATH**/ ?>